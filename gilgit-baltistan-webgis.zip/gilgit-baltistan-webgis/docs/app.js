/* Gilgit-Baltistan WebGIS: Leaflet front end.
   Data is produced by scripts/build_data.py (GeoPandas) and loaded as GeoJSON. */
"use strict";

const CATS = {
  lake:    ["Lakes and meadows",   "#2a7fa8"],
  peak:    ["Peaks and base camps", "#7a4b8c"],
  culture: ["Forts and heritage",  "#b5651d"],
  nature:  ["Valleys and parks",   "#2f7d4f"],
  pass:    ["Passes",              "#c23b3b"],
};
const $ = (id) => document.getElementById(id);
const say = (t, err) => { $("msg").textContent = t; $("msg").className = err ? "err" : ""; };

/* ---- Basemaps (all free) ---- */
const osm  = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",
  { maxZoom: 19, attribution: "&copy; OpenStreetMap contributors" });
const topo = L.tileLayer("https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
  { maxZoom: 17, attribution: "Map data &copy; OpenStreetMap contributors, SRTM | Style &copy; OpenTopoMap (CC-BY-SA)" });
const sat  = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
  { maxZoom: 18, attribution: "Tiles &copy; Esri" });

const map = L.map("map", { layers: [topo] });
map.fitBounds([[34.7, 72.4], [37.1, 77.4]]);
L.control.scale({ imperial: false }).addTo(map);

/* ---- State ---- */
let places = [];            // [{name, ll, props, marker}]
let curCat = "all", myPos = null, found = null, foundMarker = null;
const overlays = {};

/* ---- Load data ---- */
Promise.all([
  fetch("data/places.geojson").then((r) => r.json()),
  fetch("data/hub_buffers.geojson").then((r) => r.json()),
]).then(([pts, buf]) => {
  // Analysis layer produced in Python: 50 and 100 km buffers around the hubs
  overlays["Hub buffers (50 and 100 km)"] = L.geoJSON(buf, {
    style: (f) => ({ color: "#444", weight: 1, dashArray: f.properties.radius_km === 100 ? "6 4" : null,
                     fillOpacity: 0.04 }),
    onEachFeature: (f, l) => l.bindTooltip(`${f.properties.hub}: ${f.properties.radius_km} km radius`, { sticky: true }),
  });
  const baseMaps = { "Terrain (OpenTopoMap)": topo, "Streets (OpenStreetMap)": osm, "Satellite (Esri)": sat };
  L.control.layers(baseMaps, overlays).addTo(map);

  places = pts.features.map((f) => {
    const [lon, lat] = f.geometry.coordinates;
    const p = f.properties;
    const marker = L.circleMarker([lat, lon], {
      radius: p.is_hub ? 10 : 8, color: "#fff", weight: 2,
      fillColor: CATS[p.category][1], fillOpacity: 1,
    }).addTo(map).bindPopup(() => popupFor(p, places.findIndex((x) => x.name === p.name)));
    return { name: p.name, ll: L.latLng(lat, lon), props: p, marker };
  });
  buildList(); buildCats(); fillSelects(); applyFilter();
}).catch(() => say("Could not load data. Serve the docs folder over http (see README).", true));

/* ---- Popup: attributes computed in GeoPandas ---- */
function popupFor(p, i) {
  const box = document.createElement("div");
  const add = (tag, text, cls) => { const e = document.createElement(tag); e.textContent = text; if (cls) e.className = cls; box.appendChild(e); return e; };
  add("strong", p.name);
  add("div", p.description);
  add("div", `Best time: ${p.best_time}`, "facts");
  if (!p.is_hub) {
    add("div", `Nearest hub: ${p.nearest_hub}, ${p.km_to_nearest_hub} km straight line`, "facts");
    add("div", `Nearest place: ${p.nearest_place}, ${p.km_to_nearest_place} km`, "facts");
  }
  const b1 = add("button", "Directions to here");
  const b2 = add("button", "Directions from here");
  b1.onclick = () => { $("to").value = "p" + i; if (!$("from").value) $("from").value = "me"; routeNow(); map.closePopup(); };
  b2.onclick = () => { $("from").value = "p" + i; if (!$("to").value) $("to").value = "p" + (i === 0 ? 1 : 0); routeNow(); map.closePopup(); };
  return box;
}

/* ---- Sidebar ---- */
function buildList() {
  places.forEach((pl) => {
    const b = document.createElement("button"); b.className = "item";
    const dot = document.createElement("span"); dot.className = "dot"; dot.style.background = CATS[pl.props.category][1];
    const t = document.createElement("span"); t.textContent = pl.name;
    b.append(dot, t);
    b.onclick = () => { map.flyTo(pl.ll, 11); pl.marker.openPopup(); };
    pl.item = b; $("list").appendChild(b);
  });
}
function buildCats() {
  const add = (k, label) => {
    const b = document.createElement("button"); b.textContent = label; b.dataset.k = k;
    b.onclick = () => { curCat = k; applyFilter(); }; $("cats").appendChild(b);
  };
  add("all", "All"); Object.keys(CATS).forEach((k) => add(k, CATS[k][0]));
}
function applyFilter() {
  const q = $("q").value.trim().toLowerCase();
  [...$("cats").children].forEach((b) => (b.className = b.dataset.k === curCat ? "on" : ""));
  places.forEach((pl) => {
    const on = (curCat === "all" || pl.props.category === curCat) && (!q || pl.name.toLowerCase().includes(q));
    pl.item.style.display = on ? "" : "none";
    if (on) { if (!map.hasLayer(pl.marker)) pl.marker.addTo(map); } else map.removeLayer(pl.marker);
  });
}
$("q").addEventListener("input", applyFilter);

function fillSelects() {
  const keep = [$("from").value, $("to").value];
  [["from", "Choose start"], ["to", "Choose destination"]].forEach(([id, first], n) => {
    const s = $(id); s.innerHTML = "";
    const add = (v, t) => { const o = document.createElement("option"); o.value = v; o.textContent = t; s.appendChild(o); };
    add("", first); add("me", "My current location");
    places.forEach((pl, i) => add("p" + i, pl.name));
    if (found) add("found", "Searched: " + found.name);
    s.value = keep[n] || "";
  });
}

/* ---- Search the wider map (Nominatim, bounded to the study area) ---- */
$("q").addEventListener("keydown", (e) => {
  if (e.key !== "Enter" || !$("q").value.trim()) return;
  say("Searching...");
  const url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=pk" +
              "&viewbox=72.3,37.2,77.9,34.4&bounded=1&q=" + encodeURIComponent($("q").value.trim());
  fetch(url).then((r) => r.json()).then((res) => {
    if (!res.length) return say("No match found in Gilgit-Baltistan. Try another spelling.", true);
    const ll = L.latLng(+res[0].lat, +res[0].lon);
    found = { name: res[0].display_name.split(",")[0], ll };
    if (foundMarker) map.removeLayer(foundMarker);
    foundMarker = L.marker(ll).addTo(map).bindPopup(res[0].display_name).openPopup();
    map.flyTo(ll, 12); fillSelects();
    say(`Found: ${found.name}. It can now be used as a route start or destination.`);
  }).catch(() => say("Search failed. Check your internet connection.", true));
});

/* ---- Routing (OSRM public demo server, driving profile) ---- */
const router = L.Routing.control({
  waypoints: [], show: false, addWaypoints: false, routeWhileDragging: false, fitSelectedRoutes: true,
  router: L.Routing.osrmv1({ serviceUrl: "https://router.project-osrm.org/route/v1", profile: "driving" }),
  lineOptions: { styles: [{ color: "#c23b3b", weight: 5, opacity: 0.85 }] },
  createMarker: () => null,
}).addTo(map);
router.on("routesfound", (e) => {
  const s = e.routes[0].summary, h = Math.floor(s.totalTime / 3600), m = Math.round((s.totalTime % 3600) / 60);
  say(`Driving route: about ${(s.totalDistance / 1000).toFixed(0)} km, ${h ? h + " h " : ""}${m} min. Mountain roads and seasonal closures can make real travel longer.`);
});
router.on("routingerror", () => say("No route found. Roads may be missing from the map data, or the routing server is busy.", true));

function getPoint(v) {
  if (v === "me") return myPos;
  if (v === "found") return found && found.ll;
  return v && v[0] === "p" ? places[+v.slice(1)].ll : null;
}
function locate(cb) {
  if (myPos) return cb();
  if (!navigator.geolocation) return say("Location is not supported in this browser.", true);
  say("Finding your location...");
  navigator.geolocation.getCurrentPosition((pos) => {
    myPos = L.latLng(pos.coords.latitude, pos.coords.longitude);
    L.circleMarker(myPos, { radius: 7, color: "#fff", weight: 2, fillColor: "#1a73e8", fillOpacity: 1 })
      .addTo(map).bindTooltip("You are here");
    cb();
  }, () => say("Could not get your location. Allow location access (HTTPS is required).", true),
  { enableHighAccuracy: true, timeout: 15000 });
}
function routeNow() {
  const f = $("from").value, t = $("to").value;
  if (!f || !t) return say("Choose both a start and a destination.", true);
  if (f === t) return say("Start and destination are the same.", true);
  const run = () => {
    const a = getPoint(f), b = getPoint(t);
    if (!a || !b) return say("Could not resolve one of the points.", true);
    say("Calculating route..."); router.setWaypoints([a, b]);
  };
  f === "me" || t === "me" ? locate(run) : run();
}
$("go").onclick = routeNow;
$("clr").onclick = () => { router.setWaypoints([]); say(""); };
