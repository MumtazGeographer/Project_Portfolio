"""
Build the spatial datasets used by the web map.

Pipeline
1. Read and validate data/places.csv (schema, coordinate bounds, duplicates).
2. Create a GeoDataFrame in WGS84 (EPSG:4326).
3. Reproject to UTM zone 43N (EPSG:32643) so distances are measured in metres.
4. Compute: distance to each hub, nearest hub, nearest neighbouring place.
5. Build 50 km and 100 km service buffers around the hubs.
6. Export GeoJSON (back in EPSG:4326, as required by web maps) to docs/data/.

Run:  python scripts/build_data.py
"""
from pathlib import Path
import sys

import geopandas as gpd
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "data" / "places.csv"
OUT = ROOT / "docs" / "data"

WGS84 = "EPSG:4326"
UTM43N = "EPSG:32643"          # covers 72E-78E, i.e. all of Gilgit-Baltistan
BOUNDS = {"lat": (34.4, 37.2), "lon": (72.3, 77.9)}   # rough study-area extent
REQUIRED = ["name", "category", "lat", "lon", "description", "best_time", "is_hub"]
BUFFER_KM = (50, 100)


def load_and_validate(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        sys.exit(f"Missing columns in {path.name}: {missing}")
    if df["name"].duplicated().any():
        sys.exit(f"Duplicate place names: {df.loc[df['name'].duplicated(), 'name'].tolist()}")
    for axis, (lo, hi) in BOUNDS.items():
        bad = df[(df[axis] < lo) | (df[axis] > hi)]
        if not bad.empty:
            sys.exit(f"{axis} outside study area for: {bad['name'].tolist()}")
    if not (df["is_hub"] == 1).any():
        sys.exit("At least one row needs is_hub = 1")
    return df


def analyse(df: pd.DataFrame) -> gpd.GeoDataFrame:
    gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df["lon"], df["lat"]), crs=WGS84)
    utm = gdf.to_crs(UTM43N)
    hubs = utm[utm["is_hub"] == 1]

    # Straight-line distance (km) from every place to every hub
    for _, hub in hubs.iterrows():
        col = "km_to_" + hub["name"].split()[0].lower()
        gdf[col] = (utm.distance(hub.geometry) / 1000).round(1)

    hub_cols = [c for c in gdf.columns if c.startswith("km_to_")]
    gdf["nearest_hub"] = gdf[hub_cols].idxmin(axis=1).str.replace("km_to_", "", regex=False).str.title()
    gdf["km_to_nearest_hub"] = gdf[hub_cols].min(axis=1)

    # Nearest neighbouring place (excluding itself)
    nn_name, nn_km = [], []
    for i, geom in utm.geometry.items():
        d = utm.geometry.distance(geom).drop(index=i)
        nn_name.append(gdf.loc[d.idxmin(), "name"])
        nn_km.append(round(d.min() / 1000, 1))
    gdf["nearest_place"] = nn_name
    gdf["km_to_nearest_place"] = nn_km
    return gdf


def hub_buffers(df: pd.DataFrame) -> gpd.GeoDataFrame:
    h = df[df["is_hub"] == 1]
    hubs = gpd.GeoDataFrame(h, geometry=gpd.points_from_xy(h["lon"], h["lat"]), crs=WGS84).to_crs(UTM43N)
    rows = []
    for _, hub in hubs.iterrows():
        for km in BUFFER_KM:
            rows.append({"hub": hub["name"], "radius_km": km, "geometry": hub.geometry.buffer(km * 1000)})
    return gpd.GeoDataFrame(rows, crs=UTM43N).to_crs(WGS84)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    df = load_and_validate(SRC)
    places = analyse(df)
    buffers = hub_buffers(df)

    places.to_file(OUT / "places.geojson", driver="GeoJSON")
    buffers.to_file(OUT / "hub_buffers.geojson", driver="GeoJSON")

    print(f"{len(places)} places written to docs/data/places.geojson")
    print(f"{len(buffers)} hub buffers written to docs/data/hub_buffers.geojson\n")
    print("Places per category:")
    print(places["category"].value_counts().to_string(), "\n")
    far = places.sort_values("km_to_nearest_hub", ascending=False).head(3)
    print("Most remote places (straight-line km to nearest hub):")
    print(far[["name", "nearest_hub", "km_to_nearest_hub"]].to_string(index=False))


if __name__ == "__main__":
    main()
