"""
Create a standalone Python-generated web map (Folium) from the GeoJSON output.
Run after build_data.py:  python scripts/make_folium_map.py
Output: docs/folium_map.html
"""
from pathlib import Path

import folium
import geopandas as gpd

ROOT = Path(__file__).resolve().parents[1]
COLORS = {"lake": "blue", "peak": "purple", "culture": "orange", "nature": "green", "pass": "red"}

places = gpd.read_file(ROOT / "docs" / "data" / "places.geojson")
buffers = gpd.read_file(ROOT / "docs" / "data" / "hub_buffers.geojson")

m = folium.Map(location=[35.9, 74.9], zoom_start=8, tiles=None)
folium.TileLayer("OpenStreetMap", name="Streets").add_to(m)
folium.TileLayer(tiles="https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png", name="Terrain",
                 attr="OpenTopoMap (CC-BY-SA)").add_to(m)

buf_group = folium.FeatureGroup(name="Hub buffers (50 and 100 km)", show=False).add_to(m)
folium.GeoJson(buffers, style_function=lambda f: {
    "color": "#555", "weight": 1, "fillOpacity": 0.05}).add_to(buf_group)

pts = folium.FeatureGroup(name="Tourist places").add_to(m)
for _, r in places.iterrows():
    html = (f"<b>{r['name']}</b><br>{r['description']}<br>"
            f"Nearest hub: {r['nearest_hub']} ({r['km_to_nearest_hub']} km straight line)")
    folium.CircleMarker([r.geometry.y, r.geometry.x], radius=7, color="white", weight=2,
                        fill=True, fill_color=COLORS.get(r["category"], "gray"), fill_opacity=1,
                        popup=folium.Popup(html, max_width=280), tooltip=r["name"]).add_to(pts)

folium.LayerControl().add_to(m)
m.save(ROOT / "docs" / "folium_map.html")
print("Saved docs/folium_map.html")
