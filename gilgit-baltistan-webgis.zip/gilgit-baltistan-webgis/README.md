# Gilgit-Baltistan Tourist Guide: WebGIS Project

An interactive web map of tourist destinations in Gilgit-Baltistan, Pakistan. A Python (GeoPandas) pipeline prepares and analyses the spatial data, and a Leaflet web app presents it with search, filtering and routing. The project demonstrates GIS analysis, WebGIS publishing, Python programming and web mapping in one workflow.

**Live demo:** `https://<your-username>.github.io/gilgit-baltistan-webgis/`

## Skills demonstrated

| Area | What the project shows |
|---|---|
| GIS analysis | CRS handling (WGS84 and UTM 43N, EPSG:32643), projected distance calculation, nearest-neighbour analysis, buffers |
| Python | Data validation, GeoPandas/Shapely/pyproj workflow, reproducible script, Folium map generation |
| WebGIS | GeoJSON as the exchange format, static hosting on GitHub Pages, layered map with overlays |
| Web mapping | Leaflet, multiple free basemaps, category filters, geocoding search, geolocation, turn-by-turn route calculation |

## How it works

```
data/places.csv ──► scripts/build_data.py ──► docs/data/places.geojson
                      (GeoPandas, UTM 43N)    docs/data/hub_buffers.geojson
                                                   │
                      ┌────────────────────────────┴───────────────┐
                      ▼                                            ▼
          docs/index.html + app.js (Leaflet)           scripts/make_folium_map.py
          search, filters, routing, overlays           docs/folium_map.html
```

1. `build_data.py` validates the CSV (schema, duplicates, coordinate bounds), builds a GeoDataFrame, reprojects to UTM zone 43N so distances are in metres, then computes straight-line distance to each hub (Gilgit, Skardu), the nearest hub, and the nearest neighbouring place. It also builds 50 km and 100 km buffers around the hubs and exports GeoJSON in WGS84.
2. The Leaflet app loads the GeoJSON and shows the computed attributes in popups, the buffers as an optional layer, and adds the interactive tools.
3. `make_folium_map.py` produces a second, Python-only version of the map.

## Features

- Free basemaps: OpenTopoMap, OpenStreetMap, Esri satellite
- Search by place name, or press Enter to geocode anywhere in Gilgit-Baltistan (Nominatim)
- Filter by category: lakes, peaks, heritage, valleys, passes
- Routing between any two places, or from your current location (OSRM)
- Analysis layer: hub service buffers (50 and 100 km)

## Run it locally

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python scripts/build_data.py      # creates the GeoJSON files
python scripts/make_folium_map.py # optional Folium map

cd docs
python -m http.server 8000        # open http://localhost:8000
```

The web app must be served over http(s) because it loads GeoJSON with `fetch`. Browser geolocation needs HTTPS, which GitHub Pages provides (`localhost` also works).

## Publish on GitHub Pages

Repository **Settings > Pages > Build and deployment**: source `Deploy from a branch`, branch `main`, folder `/docs`.

## Adding places

Add a row to `data/places.csv` (set `is_hub` to 1 for hubs used in the distance analysis) and re-run `scripts/build_data.py`.

## Data notes and limitations

- Place coordinates and descriptions are approximate and should be verified against an authoritative source before real-world use.
- Distances in popups are straight-line distances, not road distances.
- Routing uses the free OSRM demo server with a driving profile. It is suitable for demonstration only, and mountain roads may be missing or seasonally closed.
- Basemap tiles are provided by OpenStreetMap, OpenTopoMap and Esri and are subject to their usage policies.

## Possible extensions

- Replace point attributes with data from OpenStreetMap via OSMnx
- Add a DEM-derived elevation profile for each place (rasterio)
- Store data in PostGIS and serve it through an API
- Add isochrones with OpenRouteService

## License

MIT
